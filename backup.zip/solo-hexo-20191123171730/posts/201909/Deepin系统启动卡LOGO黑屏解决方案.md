title: Deepin系统启动卡LOGO黑屏解决方案
date: '2019-09-22 00:38:40'
updated: '2019-10-13 02:21:33'
tags: [deepin, 黑屏]
permalink: /articles/2019/09/22/1569083920580.html
---
# Deepin系统启动卡LOGO黑屏解决方案
![封面](https://img.xysycx.cn/date/封面.png)
## 通常这种情况是 笔记本双显卡安装deepin
**笔记本型号 炫龙毒刺X6**
## 临时解决方案 
### 1.在开机进入选择系统界面时候不要进行选择 ，按E进入引导文本编辑界面
### 2.按照图示添加如下代码
![引导文本编辑界面](https://img.xysycx.cn/date/引导文本编辑界面.png)
``` javascript
acpi_osi=! acpi="windows 2009"
```
### 3.按下F10保存进入系统
### 4.这只是临时解决方案 为了能够正常进入系统 如果需要永久解决这个问题请参照下法
## 永久解决方案
### 1.前往deepin应用商店安装sublime
### 2.在桌面打开终端输入如下代码

``` javascript
cd /boot/grub/
```
### 3.鼠标右键 -->在文件管理器中打开
### 4.在文件管理器中找到grub.cfg
![文件管理器grub.cfg](https://img.xysycx.cn/date/文件管理器grub.cfg.png)
### 5.鼠标右键以管理员身份打开 -->输入管理密码 然后小锁标识消失 用sublime打开grub.cfg文件
### 6.CTRL+F 快捷键 输入quiet 然后在第一个quiet后加上`acpi_osi=! acpi="windows 2009"` 然后CTRL+S保存
![sublime编辑](https://img.xysycx.cn/date/sublime编辑.png)
## OVER 问题解决 
*如果问题没有得到解决，可以参考下面网址链接*
[deepin因NVIDIA显卡造成开机启动问题:卡在开机logo界面+进入桌面鼠标一直转圈](https://blog.csdn.net/HuaCode/article/details/83216338)
[深度科技论坛](https://bbs.deepin.org/)
