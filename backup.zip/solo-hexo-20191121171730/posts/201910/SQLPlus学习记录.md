title: SQLPlus学习记录
date: '2019-10-12 20:33:03'
updated: '2019-10-12 20:35:18'
tags: [Oracle.数据库, 工具学习]
permalink: /articles/2019/10/12/1570883583363.html
---
![](https://img.hacpai.com/bing/20190911.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# SQLPlus学习记录

主要介绍SQLPlus的常用命令和使用 JAVA程序连接数据库
@[toc]
- **1.命令方式启动数据库监听与服务**
- **2.SQLPlus常用命令**
- **3.SQLPlus报表命令**
- **4.SQLPlus报表命令**
- **5.使用JDBC连接数据库**


-------------------

##  1.命令方式启动数据库监听与服务


	我的电脑是win10系统,安装的oracle 11g企业版 我们可以通过dos命令来启动和关闭oracle服务
打开dos窗口（以管理员身份运行cmd）
![这里写图片描述](https://img-blog.csdn.net/2018043023261734?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1hZU1lDWA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

	执行下列命令
	
	
```
停止服务:net stop OracleServiceORCL
```

```
启动服务:net start OracleServiceORCL
```
	


## 2. SQLPlus常用命令

**登录SQLPlus的命令方式有两种**
*一种通过命令行登录控制台版的SQLPLus*

```
sqlplus
或者 sqlplus 用户名/密码
或者 sqlplus 用户名/密码@环境变量中设定的ORACLE_SID的值
```
*另一种是窗口版的SQLPlus*

```
sqlplusw
```
不过我的电脑上没有窗口版的SQLPlus，自然也就不能执行这个**sqlplusw**命令
简单介绍下
***SQLPlus命令四大分类***
	

 - ***帮助命令***
 

```
help index
```

 - ***人机交互命令***
 ![这里写图片描述](https://img-blog.csdn.net/20180501000643928?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1hZU1lDWA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
 - ***编辑命令***
 ![这里写图片描述](https://img-blog.csdn.net/20180501000704595?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1hZU1lDWA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
 - ***报表命令***
 ![这里写图片描述](https://img-blog.csdn.net/20180501000714434?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1hZU1lDWA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
 
	下面简单介绍常用的
 - `connect`      简写为`conn`  用于用户连接到数据库
 - `disconnect`简写为`disc`  断开到数据库的连接
 - `describe`    简写为`desc`. 查看数据表或视图或其他Oracle对象的结构
 - `edit`            简写为`ed`      打开sql语句文本编辑器
 -  `host`           简写为`hos`    执行dos命令
 - `sqlplus`                               登录sqlplus
 - `show`            简写为`sho`    显示系统环境变量
 - `set`                                      设置系统环境变量，仅对档案窗口有效
 - `spool`                                  捕获查询结构并输出到文件
 - `save`                                    保存缓冲区内容到指定文件
 - `@`                                          载入指定的SQL脚本文件并执行
 - `quit`                                    退出sqlplus 退出前会提交所有事务
 - 

				
	 



###  3.SQLPlus报表命令
			报表命令用于设定查询结果的显示格式-对原始数据无影响

报表命令有三种，如下

 - `ttitle`:设置报表的标题与对齐方式
 - `btitle`:设置报表的页尾文字
 - `column`:简写为`col`设置列数据的显示格式

```
SQL>col deptno heading  ‘部门编号’;	指定列标题
SQL>col dname heading ‘部门名称';
SQL>col loc format A20 heading ‘地址’; 指定列的长度
SQL>select * from dept;
SQL>col				查看所有的格式设置
SQL>col loc null ‘不详’;  		指定某一列null值的替代职值
SQL>/
SQL>col dname jus center		列标题居中对齐,left/right
SQL>col loc noprint		地址(loc)不显示在屏幕上
SQL>col deptno format $9,999 	修改数值类型列的输出格式
SQL>/
SQL>insert into dept values(51,’SALES’,’SHANGHAI’);
SQL>break on dname	屏蔽dname列的重复值
SQL>/
SQL>break 	显示屏蔽的列
SQL>clear breaks	清除屏蔽的列值

```

### 4.SQLPlus环境参数
	环境参数是在启动SQLPlus后，由数据库系统装入内存的一系列参数及其值。对照Win系统的环境变量来理解。
	环境变量方便规划SQL语句查询结果
	

 - `feedback`是否显示查询结果的行数
 - `heading`是否显示列标题
 - `linesize`设置每行显示的最大字符数
 - `newpage`设置报表每页行标题的空行数
 - `null`设置查询结果为null时的显示值
 - `numformat`设置数字值得默认显示格式
 - `numwidth`设置数字值得默认显示宽度
 - `pagesize`设置每页显示的记录行数
 - `echo`是否在执行`@`命令时显示每个SQL语句
 - `time`设置是否在`SQL>`前显示时间

```
SQL> set time on	显示当前时间
SQL> set pagesize 4	设置每页显示的记录条数
SQL> set numformat $99,999,99	设置数字的显示格式
SQL> set null ‘不详’	设置null值显示为‘不详’
SQL> set linesize 100	设置每行显示的最大字符数
SQL> set feedback on	设置显示查询结果的行数
SQL> set heading on	设置显示列标题
SQL> set echo on	显示@字符执行的每一条SQL语句
SQL> select * from dept;

```


###  5.使用JDBC连接数据库
在Oracle安装目录下找到连接数据库所需要的jar包
![这里写图片描述](https://img-blog.csdn.net/20180430233010444?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1hZU1lDWA==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
***classes12.jar***
将数据库驱动拷到你的项目中
驱动位于$oracle_home\jdbc\lib\classes12.jar
驱动类

```
oracle.jdbc.driver.OracleDriver
```

连接串
thin连接
```
jdbc:oracle:thin:@localhost:1521:sid或者本地网络服务名
```

编写DBHelper类


```
package com.qhit.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBHelper {
    public Connection conn;
    public PreparedStatement ps;
    public ResultSet rs;
    String name="newsuser";
    String pwd="newuser";
    String url="jdbc:oracle:thin:localhoset:1521:orcl";
    public Connection getConn(){
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn=DriverManager.getConnection(url,name,pwd);
            System.out.println("连接成功");
        }catch (Exception e){

        }
        return conn;
    }
    public void close(){
        try {
            if (rs!=null){
                rs.close();
            }
            if (ps!=null){
                ps.close();

            }
            if (conn!=null){
                conn.close();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}

```


----------
如有错误，请指正。