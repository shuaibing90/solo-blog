title: deepin系统在VMware中安装win10企业版虚拟机(多图预警)
date: '2019-09-12 00:00:12'
updated: '2019-10-13 02:22:26'
tags: [win10, 虚拟机, 图片教程]
permalink: /articles/2019/09/12/1568217612271.html
---
# deepin系统在VMware中安装win10企业版虚拟机
---
*此篇图片教程献给喜欢deepin系统 期望把linux系统作为主系统来折腾 却又离不开win系统的朋友*

---
![封面](https://img.xysycx.cn/date/深度截图_选择区域_20190911235748.png)

## 下载ISO镜像文件
	`ed2k://|file|cn_windows_10_business_edition_version_1903_updated_june_2019_x64_dvd_830837d9.iso|5032351744|DFF5FF3B87D209D16ECE7543255FA573|/
`
复制链接 用迅雷新建下载任务 等待下载完成
## deepin应用商店安装
![VMware](https://img.xysycx.cn/date/深度截图_选择区域_20190911230418.png)
VMware安装完成后输入激活码激活
```
YG5H2-ANZ0H-M8ERY-TXZZZ-YKRV8
```
![VMware Workstation](https://img.xysycx.cn/date/深度截图_选择区域_20190911230949.png)
打开VMware Workstation 点击创建虚拟机
![创建新的虚拟机](https://img.xysycx.cn/date/深度截图_选择区域_20190911231238.png)

![深度截图_选择区域_20190911231559](https://img.xysycx.cn/date/深度截图_选择区域_20190911231559.png)
![深度截图_选择区域_20190911231654](https://img.xysycx.cn/date/深度截图_选择区域_20190911231654.png)
![深度截图_选择区域_20190911231817](https://img.xysycx.cn/date/深度截图_选择区域_20190911231817.png)
![深度截图_选择区域_20190911232223](https://img.xysycx.cn/date/深度截图_选择区域_20190911232223.png)
![深度截图_选择区域_20190911232521](https://img.xysycx.cn/date/深度截图_选择区域_20190911232521.png)
![深度截图_选择区域_20190911232718](https://img.xysycx.cn/date/深度截图_选择区域_20190911232718.png)
![深度截图_选择区域_20190911232718](https://img.xysycx.cn/date/深度截图_选择区域_20190911232718.png)
![深度截图_选择区域_20190911233348](https://img.xysycx.cn/date/深度截图_选择区域_20190911233348.png)
![深度截图_选择区域_20190911233537](https://img.xysycx.cn/date/深度截图_选择区域_20190911233537.png)
![深度截图_选择区域_20190911233822](https://img.xysycx.cn/date/深度截图_选择区域_20190911233822.png)
## 启动虚拟机进入正常win10安装程序 接下来就是全自动了 不详细赘述
## win10激活 企业版可以选择[免费激活] (https://blog.csdn.net/wugenqiang/article/details/85446528) 或者tb购买激活码
### VMware可以给虚拟机安装VMware Tools来获得沉浸式体验 通过外接显示器实现双系统无缝切换
![深度截图_20190911235309](https://img.xysycx.cn/date/深度截图_20190911235309.png)
![深度截图_20190911235325](https://img.xysycx.cn/date/深度截图_20190911235325.png)
---
over                             ----雪月书韵茶香 www.xysycx.cn