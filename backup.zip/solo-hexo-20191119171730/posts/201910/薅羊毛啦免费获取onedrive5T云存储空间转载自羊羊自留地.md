title: 薅羊毛啦--免费获取onedrive 5T云存储空间--转载自羊羊自留地
date: '2019-10-10 23:50:49'
updated: '2019-10-10 23:52:57'
tags: [onedrive, 转载, 薅羊毛]
permalink: /articles/2019/10/10/1570722649169.html
---
![](https://img.hacpai.com/bing/20180321.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 薅羊毛啦--免费获取onedrive 5T云存储空间--转载自羊羊自留地
## 经历过百度网盘不开超级会员的痛才体会到onedrive的良心
百度网盘不开超级VIP下载网盘资源会被限速，大家有目共睹，我自己找了很久也没找到合适的免费网盘。找到的一些免费的网盘要不就是容量小的可怜要不就是垃圾广告一大堆。方的一批。前段日子朋友发我了一个链接我才晓得能免费申请免费大容量的onedrive空间。
## 自助申请步骤：

### 一、打开网址：[https://t.odmail.cn](https://t.odmail.cn/ "https://t.odmail.cn")，该网页会自动分配一个邮箱前缀给你，如果你需要自己心仪的前缀，可以在网页右上方自定义，自定义的前缀请使用**小写字母**，大写字母获取不到验证码。（该页面不要关闭了，需要获取到验证码）  
![](https://yangyang.im/post-images/1558440339073.png)  
### 二、打开Office365教育版申请地址：打开网站[https://signup.microsoft.com/signup?sku=student](https://signup.microsoft.com/signup?sku=student "https://signup.microsoft.com/signup?sku=student")（学生版）或[https://signup.microsoft.com/signup?sku=faculty](https://signup.microsoft.com/signup?sku=faculty "https://signup.microsoft.com/signup?sku=faculty")（教职员工版），填入刚刚获取到的邮箱地址，再点“注册”  
![](https://yangyang.im/post-images/1558440359631.png)  
随后填下信息和密码，验证码在临时邮箱页面获取，  
![](https://yangyang.im/post-images/1558440378783.png)

![](https://yangyang.im/post-images/1558440396184.png)  
下个页面直接点“跳过”  
![](https://yangyang.im/post-images/1558440411714.png)  
注册好了，点“下一步”，设置下账户安全设置  
![](https://yangyang.im/post-images/1558440430180.png)  
为了你的账户安全，请尽可能的设置下密保，不设置也可以，直接点“取消”  
![](https://yangyang.im/post-images/1558440449321.png)  
好了，现在已经完成注册了，很简单吧？进去后可以使用在线版的office和5T的云盘了，该全局不带桌面版的office的，只有5T的OneDrive云盘可用，  
![](https://yangyang.im/post-images/1558440465242.png)  
![](https://yangyang.im/post-images/1558440482674.png)
---
转载原文地址：[羊羊自留地](https://yangyang.im/post/ONKcbU4-k/)
更详细的说明去原作者的博客查阅吧。
非常感谢羊羊自留地免费提供的临时邮箱以及详细的注册说明造福大众。