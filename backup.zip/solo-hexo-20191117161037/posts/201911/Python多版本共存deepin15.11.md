title: Python多版本共存 --deepin 15.11
date: '2019-11-12 00:10:19'
updated: '2019-11-12 21:42:14'
tags: [deepin, python]
permalink: /articles/2019/11/12/1573488619099.html
---
# Python多版本共存 --deepin 15.11
deepin 系统默认使用的是python版本是python2.7.13
![deepin默认python版本](https://img.xysycx.cn/date/deepin默认python版本.png)
虽然我已经设置了python3和python2分开但是还是感觉不是很方便
然后我就在想有没没有一种办法可以设置python3为全局环境变量供用户使用而系统脚本默认使用自带的python2呢
机缘巧合之下我了解到了[pyenv](https://github.com/pyenv/pyenv-installer)一个python多版本管理工具可以实现这个功能
下面是我的探索出来的安装步骤　给拥有同样需求的小伙伴们一个参考
# pyenv安装前准备
避免中途出现安装失败　先执行安装如下依赖
``` shell
sudo apt-get install -y make build-essential libssl-dev zlib1g-dev libbz2-dev \
libreadline-dev libsqlite3-dev wget curl llvm libncurses5-dev libncursesw5-dev \
xz-utils tk-dev libffi-dev liblzma-dev python-openssl
```
执行预览
![1](https://img.xysycx.cn/date/1.png)

安装libreadline-dev环境

``` shell
sudo apt install libedit-dev
```
执行预览
![2](https://img.xysycx.cn/date/2.png)

# pyenv安装

``` shell
curl -L https://github.com/pyenv/pyenv-installer/raw/master/bin/pyenv-installer | bash
```
执行预览
![3](https://img.xysycx.cn/date/3.png)
执行完后　红色框选处的环境变量复制一下（每个人的不一样）　下一步配置pyenv的环境变量时候要用
## 配置pyenv的环境变量

``` shell
sudo vim /etc/profile
```
![4](https://img.xysycx.cn/date/4.png)
如果VIM编辑器不会用的可以用本地编辑器如本地编辑器打开配置环境变量
	先进入![4.1](https://img.xysycx.cn/date/4.1.png)
		在输入路径直接本地编辑器打开文件
		![4.2](https://img.xysycx.cn/date/4.2.png)
		
然后ctrl+s保存
## 重新载入环境变量配置

``` shell
source /etc/profile
```
# 使用pyenv
## 查看pyenv 可安装软件

```　shell
pyenv install --list
```
执行预览

``` shell
xysycx@xysycx-PC:~$ pyenv install --list
Available versions:
  2.1.3
  2.2.3
  2.3.7
  2.4.0
  2.4.1
  2.4.2
  2.4.3
  2.4.4
  2.4.5
  2.4.6
  2.5.0
  2.5.1
  2.5.2
  2.5.3
  2.5.4
  2.5.5
  2.5.6
  2.6.6
  2.6.7
  2.6.8
  2.6.9
  2.7.0
  2.7-dev
  2.7.1
  2.7.2
  2.7.3
  2.7.4
  2.7.5
  2.7.6
  2.7.7
  2.7.8
  2.7.9
  2.7.10
  2.7.11
  2.7.12
  2.7.13
  2.7.14
  2.7.15
  2.7.16
  2.7.17
  3.0.1
  3.1.0
  3.1.1
  3.1.2
  3.1.3
  3.1.4
  3.1.5
  3.2.0
  3.2.1
  3.2.2
  3.2.3
  3.2.4
  3.2.5
  3.2.6
  3.3.0
  3.3.1
  3.3.2
  3.3.3
  3.3.4
  3.3.5
  3.3.6
  3.3.7
  3.4.0
  3.4-dev
  3.4.1
  3.4.2
  3.4.3
  3.4.4
  3.4.5
  3.4.6
  3.4.7
  3.4.8
  3.4.9
  3.4.10
  3.5.0
  3.5-dev
  3.5.1
  3.5.2
  3.5.3
  3.5.4
  3.5.5
  3.5.6
  3.5.7
  3.5.8
  3.5.9
  3.6.0
  3.6-dev
  3.6.1
  3.6.2
  3.6.3
  3.6.4
  3.6.5
  3.6.6
  3.6.7
  3.6.8
  3.6.9
  3.7.0
  3.7-dev
  3.7.1
  3.7.2
  3.7.3　＃这个就是我需要的版本
  3.7.4
  3.7.5
  3.7.5rc1
  3.8.0
  3.8-dev
  3.9-dev
＃后面还有很长

```
## pyenv安装python3.7.3

``` shell
pyenv install 3.7.3
```
执行预览　可能时间要久一点　耐心等待
![5](https://img.xysycx.cn/date/5.png)
显示已经安装完成
## 查看pyenv当前使用的python版本

``` shell
pyenv versions
```
执行预览
![6](https://img.xysycx.cn/date/6.png)
可以看到pyenv已经安装的python3.7.3
接下里我就开始设置python3.7.3为全局变量
## 设置pyenv安装的python3.7.3为全局变量
－－实现用户打开任意终端输入python就能使用python3.7.3而且不影响系统脚本使用的python2.7.13

``` shell
pyenv global 3.7.3
```
回车之后终端没有任何输出但是接下来就是见证奇迹的时刻

``` shell
python
```
执行预览
![7](https://img.xysycx.cn/date/7.png)
哇哦！再试试pip能用不

``` shell
pip install ipython
```
pyenv安装的python的话，pip命令已经有了
成功安装
！！！舒服



![8](https://img.xysycx.cn/date/8.png)
**每次打开新的终端之前都要执行下面的指令来使环境变量生效**
``` shell
source /etc/profile
```
# pyenv常用命令

``` shell
pyenv install --list # 列出可安装版本
pyenv install <version> # 安装对应版本
pyenv install -v <version> # 安装对应版本，若发生错误，可以显示详细的错误信息
pyenv versions # 显示当前使用的python版本
pyenv which python # 显示当前python安装路径
pyenv global <version> # 设置默认Python版本
pyenv local <version> # 当前路径创建一个.python-version, 以后进入这个目录自动切换为该版本
pyenv shell <version> # 当前shell的session中启用某版本，优先级高于global 及 local
```


----------
博主安装过程中没有遇到什么问题，安装之后也一切顺利并没有遇到一些应用不能用的问题
如果你在安装过程中或者之后遇到了什么问题，可以一起文章底部留下你的问题，一起学习解决

