title: 计算机专业书籍PDFpool--使用onedrive下载
date: '2019-10-10 23:56:47'
updated: '2019-10-10 23:58:00'
tags: [计算机图书, 资源分享]
permalink: /articles/2019/10/10/1570723006901.html
---
![](https://img.hacpai.com/bing/20181014.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# [点我下载](https://jxjjxy-my.sharepoint.com/:f:/g/personal/xysycx_t_odmail_cn/EpEHU6eQdnJEoGjG-9PQHTEBp9cG7p8ZmLXzTrqp7l3NFw?e=hMKKv6)